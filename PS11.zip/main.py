def compute_discount(quantity, price, discount_rate):
  discount_amount = quantity * price * discount_rate / 100

 
  discounted_price = quantity * price - discount_amount

 
  return discount_amount, discounted_price

if __name__ == "__main__":
  quantity = int(input("Enter the quantity: "))
  price = float(input("Enter the price per item: "))
  discount_rate = float(input("Enter the discount rate (%): "))

  
  discount_amount, discounted_price = compute_discount(quantity, price, discount_rate)

  
  print("\nInput Values:")
  print(f"Quantity: {quantity}")
  print(f"Price per Item: ${price:.2f}")
  print(f"Discount Rate: {discount_rate}%")

  print("\nComputed Values:")
  print(f"Discount Amount: ${discount_amount:.2f}")
  print(f"Discounted Price: ${discounted_price:.2f}")
