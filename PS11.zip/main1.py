def compute_exam_stats(scores):
  # Calculate the total points and average exam score
  total_points = sum(scores)
  average_score = total_points / len(scores)

  # Return the total points and average score
  return total_points, average_score

if __name__ == "__main__":
  last_name = input("Enter student's last name: ")
  exam_scores = [float(input(f"Enter Exam Score {i + 1}: ")) for i in range(3)]
 
  total_points, average_score = compute_exam_stats(exam_scores)

  print("\nStudent Information:")
  print(f"Last Name: {last_name}")

  print("\nExam Scores:")
  for i, score in enumerate(exam_scores, start=1):
      print(f"Exam {i}: {score}")

  print("\nComputed Values:")
  print(f"Total Points: {total_points}")
  print(f"Average Exam Score: {average_score:.2f}")
