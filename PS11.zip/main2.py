def compute_commission_and_target(sales_amount):
  high_sales_commission_rate = 0.10
  low_sales_commission_rate = 0.05
  next_year_target_rate = 0.05

  if sales_amount > 100000:
      commission_rate = high_sales_commission_rate
  else:
      commission_rate = low_sales_commission_rate

  commission = sales_amount * commission_rate
  next_year_target = sales_amount * next_year_target_rate

  return commission, next_year_target

if __name__ == "__main__":
  last_name = input("Enter salesperson's last name: ")
  sales_amount = float(input("Enter sales amount: "))

  commission, next_year_target = compute_commission_and_target(sales_amount)

  print("\nSales Report:")
  print(f"Salesperson's Name: {last_name}")
  print(f"Sales Amount: ${sales_amount:.2f}")
  print(f"Commission: ${commission:.2f}")
  print(f"Next Year's Target: ${next_year_target:.2f}")
