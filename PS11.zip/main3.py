def compute_average_scores_and_handicap(game_scores, handicap):
  average_score = sum(game_scores) / len(game_scores)

  average_score_with_handicap = average_score + handicap

  return average_score, average_score_with_handicap

if __name__ == "__main__":
  last_name = input("Enter bowler's last name: ")
  game_scores = [float(input(f"Enter game {i + 1} score: ")) for i in range(3)]
  handicap = float(input("Enter handicap: "))

  average_score, average_score_with_handicap = compute_average_scores_and_handicap(game_scores, handicap)

  print("\nBowler's Performance:")
  print(f"Bowler's Last Name: {last_name}")
  print(f"Average Score: {average_score:.2f}")
  print(f"Average Score with Handicap: {average_score_with_handicap:.2f}")
