total = 0.0
tax = 0.0

def compute_total_and_tax(quantity, unit_price):
    global total, tax

    total = quantity * unit_price

    tax = 0.07 * total

if __name__ == "__main__":
    quantity = int(input("Enter quantity of the item: "))
    unit_price = float(input("Enter unit price: "))
    compute_total_and_tax(quantity, unit_price)

    print("\nTransaction Details:")
    print(f"Quantity: {quantity}")
    print(f"Unit Price: ${unit_price:.2f}")
    print(f"Total: ${total:.2f}")
    print(f"Tax (7% of Total): ${tax:.2f}")
