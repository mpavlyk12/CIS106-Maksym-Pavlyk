def display_student_info(names, scores):
  """Display student information including last names and exam scores."""
  print("Student Information:")
  for i in range(len(names)):
      print(f"Name: {names[i]}, Score: {scores[i]}")

def display_student_info_reverse(names, scores):
  """Display student information in reverse order including last names and exam scores."""
  print("\nStudent Information in Reverse Order:")
  for i in reversed(range(len(names))):
      print(f"Name: {names[i]}, Score: {scores[i]}")

# Assign 10 last names and exam scores to arrays
last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown",
            "Davis", "Miller", "Wilson", "Moore", "Taylor"]
exam_scores = [85, 90, 78, 92, 88, 75, 85, 94, 89, 80]

# Display student information in the original order
display_student_info(last_names, exam_scores)

# Display student information in reverse order
display_student_info_reverse(last_names, exam_scores)