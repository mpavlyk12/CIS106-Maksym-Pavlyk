def load_data_from_file(main1.py):
  """THis is for uploading name and score, i dont know if i did this correct but ive seen it like this in a few examples i found"""
  last_names = []
  scores = []
  with open(filename, 'r') as file:
      for line in file:
          data = line.strip().split(',')
          last_names.append(data[0])
          scores.append(int(data[1]))
  return last_names, scores

def display_student_info(names, scores):
  """Display student information including last names and exam scores."""
  print("Student Information:")
  for i in range(len(names)):
      print(f"Name: {names[i]}, Score: {scores[i]}")

def display_highest_lowest(names, scores):
  """Display the last name with the highest and lowest scores."""
  high_var = 0
  low_var = 999
  high_index = 0
  low_index = 0

  for i in range(len(scores)):
      if scores[i] > high_var:
          high_var = scores[i]
          high_index = i
      if scores[i] < low_var:
          low_var = scores[i]
          low_index = i

  print("\nStudent with the Highest Score:")
  print(f"Name: {names[high_index]}, Score: {high_var}")

  print("\nStudent with the Lowest Score:")
  print(f"Name: {names[low_index]}, Score: {low_var}")


# Display student information
display_student_info(last_names, exam_scores)

# Display the last name with the highest and lowest scores
display_highest_lowest(last_names, exam_scores)