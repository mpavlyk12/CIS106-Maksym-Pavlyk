def load_player_data_from_file(namesscore.py):
  last_names = []
  batting_averages = []
  with open(filename, 'r') as file:
      for line in file:
          data = line.strip().split(',')
          last_names.append(data[0])
          batting_averages.append(float(data[1]))
  return last_names, batting_averages

def display_player_data(names, averages):
  """Display player information including last names and batting averages."""
  print("\nPlayer Information:")
  for i in range(len(names)):
      print(f"Name: {names[i]}, Batting Average: {averages[i]}")

def search_and_display_player(name, names, averages):
  """Search for a player by last name and display their information."""
  index = names.index(name) if name in names else -1
  if index != -1:
      print(f"\nPlayer Found - Name: {names[index]}, Batting Average: {averages[index]}")
  else:
      print(f"\nPlayer not found for last name: {name}")

# Load player data from a file (assuming the file has lines in the format: lastname,average)
filename = 'player_data.txt'
player_last_names, player_averages = load_player_data_from_file(namesscore.py)

# Display player information
display_player_data(player_last_names, player_averages)

# Use a while loop to repeatedly ask the user for a last name and search for the player
while True:
  search_name = input("\nEnter a last name to search for (or type 'exit' to end): ").capitalize()

  if search_name.lower() == 'exit':
      break

  search_and_display_player(search_name, player_last_names, player_averages)
