player_last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown",
            "Davis", "Miller", "Wilson", "Moore", "Taylor"]
player_averages = [0.267, 0.198, 0.445, 0.300, 0.350, 0.070, 0.356, 0.226, 0.319, 0.127]