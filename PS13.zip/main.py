class Employee:
  def __init__(self, first, last, salary):
      self.first = first
      self.last = last
      self.salary = salary

  def calculate_bonus(self, bonus_rate):
      bonus = self.salary * bonus_rate
      return bonus


if __name__ == "__main__":
  emp = Employee("John", "Doe", 50000)

  try:
      bonus_rate = float(input("Enter the bonus rate (as a decimal): "))
  except ValueError:
      print("Invalid input. Please enter a valid decimal number for the bonus rate.")
  else:
      # Calculating and displaying the bonus
      bonus_amount = emp.calculate_bonus(bonus_rate)
      print(f"{emp.first} {emp.last}'s bonus at a rate of {bonus_rate:.2%} is: ${bonus_amount:.2f}")
