class Student:
  def __init__(self, first_name, last_name, district_code, enrolled_credits):
      self.first_name = first_name
      self.last_name = last_name
      self.district_code = district_code
      self.enrolled_credits = enrolled_credits

  def compute_tuition(self):
      in_district_rate = 250.00
      out_of_district_rate = 500.00

      if self.district_code == 'I':
          tuition = self.enrolled_credits * in_district_rate
      else:
          tuition = self.enrolled_credits * out_of_district_rate

      return tuition


if __name__ == "__main__":
  student1 = Student("John", "Doe", "I", 12)  
  student2 = Student("Jane", "Smith", "O", 15)  

  # Test the compute_tuition method
  tuition1 = student1.compute_tuition()
  tuition2 = student2.compute_tuition()

  # Display the results
  print(f"{student1.first_name} {student1.last_name}'s tuition: ${tuition1:.2f}")
  print(f"{student2.first_name} {student2.last_name}'s tuition: ${tuition2:.2f}")
