#input phase
symbol = input("Enter the stock symbol")
number = float(input("Enter the number of shares"))
cost = float(input("Enter the cost of each share"))

#process phase
invested = number * cost

#output phase
print( "Your stock is: ", symbol)
print(" Total amount invested ", invested)
