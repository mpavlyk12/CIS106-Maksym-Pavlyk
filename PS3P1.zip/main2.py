#input phase
undivided = float(input(" Enter the amount received"))
ppl = float(input("Enter the number of people"))

#process phase
divided = undivided/ppl

#output phase
print("Each person should receive", divided)
