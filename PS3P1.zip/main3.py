#input phase
make = input("Enter the make of the car ")
model = input("Enter the model ")
msrp = float(input("Enter the MSRP "))
discount = float(input("Enter the discount "))

#process phase
amountoff = msrp * discount
finalprice = msrp - amountoff

#outputphase
print("You save ", amountoff)
print("Your discounted final price ", finalprice)
