#input phase
radius = float(input("Enter the radius "))

#proces phase
pie = 3.174
area = pie * (radius*radius)
perimeter = 2*pie *radius

#output phase
print("Your area is ", area)
print("Your perimeter is ", perimeter)