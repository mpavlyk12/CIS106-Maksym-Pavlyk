#input phase
exam1 = float(input("Enter score for exam 1 "))
exam2 = float(input("Enter score for exam 2 "))

#processing phase
total = exam1*(60/100) + exam2*(40/100)

#output phase
print("Your total score is", total)