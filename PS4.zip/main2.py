#input phase
purchase = float(input("What was the purchase price per share "))
current = float(input("What is the current stock price "))
quantity = float(input("What is the quantity of shares "))
#processing phase
value = (current - purchase) * quantity

#output phase
print("The value of the stock is $", value)