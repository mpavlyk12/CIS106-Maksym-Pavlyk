#input phase
total = float(input("What is the total "))
tip = float(input("What is the tip percentage "))

#processing phase
tip_amount = total * tip / 100
total_bill = total + tip_amount

#output phase
print("The tip amount is $", tip_amount)
print("The total bill is $", total_bill)