#input phase
name = input("What's your name ")
steps = float(input("How many steps have you taken? "))

#processing phase
calories = steps * 0.25

#output phase
print("Hello", name, "! You have burned", calories, "calories.")