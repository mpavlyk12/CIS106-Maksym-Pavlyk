#input phase
fixed = float(input("What is the fixed cost? "))
price = float(input("What is the price per unit? "))
cost = float(input("What is the cost per unit? "))

#process phase
even = fixed/ (price - cost)

#output phase
print("The breakeven point is: ", even)