item = imput(" item A or B ")
quantuty = float(input(" What's the quantuty "))

if item:
  A=10
else:
  B=20

extprice = item * quantity
print(" The ext price is $", extprice)
print(" The item is ", item)
prin(" Your quantity is  ", quantity)
