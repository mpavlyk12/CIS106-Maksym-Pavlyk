number = float(input("Number of books ordered"))
cost = float(input(" Cost per book"))
total = number * cost
if total >= 50:
    shipping = 0.0
else:
    shipping = 25.0
total1 = total + shipping
print(" Shipping charge is $", shipping)
print("Total is $ ", total1)
