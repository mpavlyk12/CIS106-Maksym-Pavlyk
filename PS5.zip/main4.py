name = input(" What's the name of the appliance? ")
cost = float(input( " What's the cost of the appliance? "))
if cost >= 1000:
    warranty = cost * 0.1
else:
    warranty = cost * 0.05
total = cost + warranty
print(" The appliance is ", name)
print("The cost is $ ", cost)
print(" Cost of warranty is $ ", warranty)
print(" Total is $ ", total)
