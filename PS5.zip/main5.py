name = input(" What's your last name ")
dependents = float(input("What's the number of dependents "))
gross = float(input(" What's your gross income"))
adj = gross - dependents * 12000
if adj >= 50000:
    tax = 0.2
else:
    tax = 0.1
intax = adj * tax
if intax <= 0:
    intax = 100
print("Your last name is " + name)
print("Your gross income is $", gross)
print("Number of dependants: ", dependents)
print("Your adjusted gross income is $",  adj)
print("Your income tax is $", intax)
