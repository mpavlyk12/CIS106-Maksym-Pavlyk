price = 0
qnty = float(input("What's the quantity? "))
if qnty > 10000:
    price = 10
else:
    if qnty >= 5000 and qnty < 10000:
        price = 20
    else:
        if qnty <= 5000:
            price = 30
extprice = qnty * price
tax = extprice * 0.07
total = extprice + tax
print("Your extended price is $" , extprice)
print("Your tax is $" , tax)
print("Your total is $" , total)
