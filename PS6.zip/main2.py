partno = int(input("What's the part number"))
qnty = float(input("How many do you want?"))
if partno == 10 or partno == 55:
    unitprice = 1.0
else:
    if partno == 99:
        unitprice = 2.0
    else:
        if partno == 80 or partno == 70:
            unitprice = 3.0
        else:
            unitprice = 5.0
total = unitprice * qnty
print(partno)
print(qnty)
print(unitprice)
print(total)
