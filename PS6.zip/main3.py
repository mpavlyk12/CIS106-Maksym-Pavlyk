prin = float(input(" What's the principal amount? "))
yrs = float(input(" Year to maturity "))
if prin > 100000 and yrs == 5:
    rate = 0.06
else:
    if prin >= 50000 and prin < 100000 and yrs == 10:
        rate = 0.05
    else:
        if prin >= 50000 and prin < 100000 and yrs == 5:
            rate = 0.04
        else:
            rate = 0.02
amount = prin * rate
print(prin)
print(rate)
print(amount)
