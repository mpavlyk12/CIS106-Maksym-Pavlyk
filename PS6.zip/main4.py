qty = float(input("What's the quantity? "))
if qty >= 25:
    price = 50
else:
    if qty >= 10 and qty < 24:
        price = 60
    else:
        if qty >= 5 and qty <= 9:
            price = 70
        else:
            price = 75
total = price * qty
print(qty)
print(price)
print(total)
