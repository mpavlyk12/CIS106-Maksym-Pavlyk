name = int(input("What is the last name name? "))
salary = float(input("What is the salary? "))
lvl = float(input("What is the job level? "))
if lvl >= 10:
    rate = 0.25
else:
    if lvl >= 5 and lvl <= 9:
        rate = 0.2
    else:
        rate = 0.1
bonus = salary * rate
print(name)
print(bonus)
