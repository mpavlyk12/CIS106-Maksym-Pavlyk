startv = 1
stopv = 25
incrv = 2
while startv <= stopv:
    print("Loop - start valuet" + str(startv))
    startv = startv + incrv
