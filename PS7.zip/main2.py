startv = int(input("Enter the starting value: "))
stopv = int(input("Enter the stopping value: "))
incrv = int(input("Enter the increment value: "))
while startv <= stopv:
    print("Loop - start valuet" + str(startv))
    startv = startv + incrv
    print("Loop - stop value: " + str(stopv)
    print("Loop - increment value: " + str(incrv)