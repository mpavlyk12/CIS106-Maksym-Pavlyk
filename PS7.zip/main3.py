totalex1 = 0
counter = 0
print("Do you want to compute your average score (Yes or No)")
response = input()
while response == "Yes":
    counter = counter + 1
    print("Enter student last name")
    lastname = input()
    print("Enter exam score 1")
    score1 = float(input())
    print("Enter exam score 2")
    score2 = float(input())
    avg = (score1 == score2) / 2
    totalex1 = totalex1 + score1
    print("Student" + lastname + "has average of" + str(avg))
print("Total number of students" + str(counter))
avgex1 = totalex1 / counter
print("Average exam score 1 is " + str(avgex1))
