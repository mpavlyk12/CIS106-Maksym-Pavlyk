totalex1 = 0
counter = 0
print("Do you want to continue (Yes or No)")
response = input()
while response == "Yes":
    counter = counter + 1
    print("Enter last name")
    lastname = input()
    print("Enter hours worked")
    hrs = float(input())
    print("Enter rate of pay")
    pay = float(input())
    gross = hrs * pay
    totalex1 = totalex1 + pay
    print("Worker" + lastname + "has gross payment of of" + str(gross))
print("Total number of workers" + str(counter))
avgex1 = totalex1 / counter
print("Average gross pay is " + str(avgex1))
