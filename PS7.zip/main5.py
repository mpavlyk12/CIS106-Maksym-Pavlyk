totalex1 = 0
print("Do you want to continue (Yes or No)")
response = input()
while response == "Yes":
    print("Enter quantity")
    qnty = float(input())
    print("Enter price")
    price = float(input())
    extprice = qnty * price
    if extprice >= 10000.0:
        discount = 0.25
    else:
        discount = 0.1
    amount = extprice * discount
    total = extprice - amount
print("Do you want to do this again (Yes or No)")
print(price)
print(qnty)
print(extprice)
print(amount)
print(total)
print(discount)
