totalint = 0.0
print("Do you want to calculate interest?(Yes or No)")
response = input()
while response == "Yes":
    print("Enter amount to invest")
    p = float(input())
    print("Enter interest rate")
    rate = float(input())
    for year in range(1, 5 + 1, 1):
        intamt = p * rate
        endbal = p + intamt
        print(str(year) + str(p) + str(endbal))
        totalint = totalint + intamt
        p = endbal
    print("Do another calculation(Yes or No)")
    response = input()
print("Total interest Earned" + str(totalint))
