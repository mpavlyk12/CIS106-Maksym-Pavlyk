totalint = 0.0
response = input()
while response == "Yes":
    print("enter number")
    p = float(input())
    for sequence in range(1, 20 + 1, 1):
        intamt = p * rate
        endbal = p + intamt
        print(str(year) + str(p) + str(endbal))
        totalint = totalint + intamt
        p = endbal
    print("Do another calculation(Yes or No)")
    response = input()
print("number" + str(p))
