
print("Do you want to calculate bonus(Yes or No)")
response = input()
while response == "Yes":
    print("Enter salary")
    p = float(input())
    print("Enter name")
    name = input()
    if p >= 100000:
        rate = 0.2
    else:
        if p == 50000:
            rate = 0.15
        else:
            rate = 0.1
    bonus = p * rate
    print("Do another calculation(Yes or No)")
    response = input()
print(p)
print(rate)
print(bonus)
