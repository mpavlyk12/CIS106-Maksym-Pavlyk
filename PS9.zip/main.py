qnty = float(input())
price = float(input())
total = qnty * price
if total >= 10000000:
    disc = 0.1
else:
    disc = 0
r = total * disc
extprice = total - r
print(extprice)
