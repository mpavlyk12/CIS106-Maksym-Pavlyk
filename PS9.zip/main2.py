name = input()
bats = float(input())
games = float(input())
avr = bats / games
print(name)
print(avr)
