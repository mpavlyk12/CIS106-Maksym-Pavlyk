city = input()
miles = float(input())
gallons = float(input())
mpg = miles / gallons
print(city)
print(miles)
print(mpg)
