name = input()
code = float(input())
hours = float(input())
code = LAJ
l = 25
a = 30
j = 50
gross = code * hours
print(name)
print(gross)
