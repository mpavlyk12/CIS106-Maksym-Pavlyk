name = input()
code = float(input())
hours = float(input())
code = I
code = O
I = 250
O = 550
gross = code * hours
print(name)
print(gross)
